-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : ciex
-- 
-- Part : #1
-- Date : 2018-09-03 13:53:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `zx_bonus_count`
-- -----------------------------
DROP TABLE IF EXISTS `zx_bonus_count`;
CREATE TABLE `zx_bonus_count` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `touserid` int(10) DEFAULT NULL,
  `tousernumber` varchar(16) DEFAULT NULL,
  `bonus1` decimal(10,2) DEFAULT '0.00' COMMENT '直推奖',
  `bonus2` decimal(10,2) DEFAULT '0.00' COMMENT '碰对奖',
  `bonus3` decimal(10,2) DEFAULT '0.00' COMMENT '见点奖',
  `bonus4` decimal(10,2) DEFAULT '0.00' COMMENT '日分红',
  `bonus5` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为5的奖项',
  `bonus6` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为5的奖项',
  `bonus7` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为5的奖项',
  `bonus8` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为5的奖项',
  `total` decimal(16,2) DEFAULT '0.00' COMMENT '奖金累计',
  `count_date` int(8) DEFAULT NULL,
  `cp_money` decimal(10,2) DEFAULT '0.00' COMMENT '复消累计',
  `tax_money` decimal(10,2) DEFAULT '0.00' COMMENT '复消累计',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='奖金日统计表';

-- -----------------------------
-- Records of `zx_bonus_count`
-- -----------------------------
INSERT INTO `zx_bonus_count` VALUES ('1', '14', '18589020061', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '21332.40', '0.00', '4820.64', '1535644800', '0.00', '0.00');
INSERT INTO `zx_bonus_count` VALUES ('2', '15', '18589020062', '0.00', '0.00', '0.00', '0.00', '0.14', '0.00', '6620.80', '0.00', '70.10', '1535644800', '0.00', '0.00');
INSERT INTO `zx_bonus_count` VALUES ('3', '14', '18589020061', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '350.00', '0.00', '627.65', '1535731200', '0.00', '0.00');
INSERT INTO `zx_bonus_count` VALUES ('4', '15', '18589020062', '0.00', '0.00', '0.00', '0.00', '17.50', '0.00', '170.00', '0.00', '52063.77', '1535731200', '0.00', '0.00');

-- -----------------------------
-- Table structure for `zx_bonus_rule`
-- -----------------------------
DROP TABLE IF EXISTS `zx_bonus_rule`;
CREATE TABLE `zx_bonus_rule` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '' COMMENT '规则名称',
  `level_money` text COMMENT '报单金额(单级别)',
  `recom_money` varchar(255) DEFAULT NULL COMMENT '直推奖',
  `leader_money` varchar(255) DEFAULT NULL COMMENT '领导奖',
  `level_recom_rate` text COMMENT '直推奖(%)',
  `level_amount_rate` text COMMENT '见点奖',
  `day_roof_money` text COMMENT '不同级别见点奖层数',
  `tax_rate` double(5,2) DEFAULT '0.00' COMMENT '比例',
  `cp_rate` double(5,2) DEFAULT '0.00' COMMENT '管理奖(%)',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `min_tf` int(8) DEFAULT '0' COMMENT '最低转账金额',
  `multiple_tf` int(4) DEFAULT '0' COMMENT '转币倍数',
  `max_wd_fee` double(8,0) DEFAULT '0' COMMENT '手续费封顶',
  `min_wd` double(10,2) DEFAULT '0.00' COMMENT '最低提现金额',
  `multiple_wd` int(4) DEFAULT '0' COMMENT '提现倍数',
  `fee_wd` int(8) DEFAULT '0' COMMENT '提现手续费（%）',
  `wd_time` varchar(255) DEFAULT NULL COMMENT '提现时间限制',
  `kuangji` varchar(255) DEFAULT NULL COMMENT '矿机详情',
  `dt_money` varchar(255) DEFAULT NULL COMMENT '动态奖',
  `dt_tiaojian` double DEFAULT '0' COMMENT '动态收益限制',
  `level` varchar(255) DEFAULT NULL COMMENT '级别要求',
  `fukuan` varchar(255) DEFAULT NULL COMMENT '匹配后付款时间',
  `qr_fukuan` varchar(255) DEFAULT NULL COMMENT '付款后确认收款',
  `jy_rate` varchar(255) DEFAULT NULL COMMENT '交易手续费',
  `yixing` varchar(255) DEFAULT NULL COMMENT '一星矿主条件',
  `erxing` varchar(255) DEFAULT NULL COMMENT '二星矿主条件',
  `sanxing` varchar(255) DEFAULT NULL COMMENT '三星矿主条件',
  `sixing` varchar(255) DEFAULT NULL COMMENT '四星矿主条件',
  `song` int(11) DEFAULT '0' COMMENT '要送的云矿机id',
  `eve_price` decimal(20,2) DEFAULT '0.00' COMMENT '今日币价',
  `appid` varchar(255) DEFAULT NULL COMMENT '短信接口',
  `gs_name` varchar(255) DEFAULT NULL COMMENT '短信内容设置',
  `pp_time` char(12) DEFAULT NULL COMMENT '匹配时间',
  `dk_time` char(12) DEFAULT NULL COMMENT '打款时间',
  `fu` varchar(255) DEFAULT NULL COMMENT '幅度',
  `liang` varchar(255) DEFAULT NULL,
  `low` varchar(255) DEFAULT NULL,
  `hight` varchar(255) DEFAULT NULL,
  `renshu` varchar(255) DEFAULT NULL,
  `rixian` varchar(255) DEFAULT NULL,
  `fenxian` varchar(255) DEFAULT NULL,
  `allsl` decimal(30,0) NOT NULL DEFAULT '0',
  `kaiguan` tinyint(4) DEFAULT '0' COMMENT '0关1开',
  `xiao` tinyint(4) DEFAULT '0' COMMENT '小型云矿机id',
  `zhong` tinyint(4) DEFAULT '0' COMMENT '中型云矿机',
  `da` tinyint(4) DEFAULT '0' COMMENT '大型云矿机',
  `chao` tinyint(4) DEFAULT '0' COMMENT '超级云矿机',
  `duanxin` int(11) DEFAULT '0' COMMENT '短信条数',
  `start` tinyint(4) DEFAULT '0' COMMENT '交易开始时间',
  `end` tinyint(4) DEFAULT '0' COMMENT '交易结束时间',
  `huilv` varchar(255) DEFAULT '0' COMMENT '汇率',
  `vip_pay` decimal(10,2) DEFAULT '0.00' COMMENT '成为vip需要多少agL',
  `vip_shouxu` int(10) DEFAULT '0' COMMENT 'vip手续费',
  `dl_money` decimal(10,2) DEFAULT '0.00',
  `dl_tuijian` int(11) DEFAULT '0' COMMENT '代理商推荐人',
  `dl_suanli` decimal(10,2) DEFAULT '0.00',
  `q_min` int(10) NOT NULL,
  `q_max` int(10) NOT NULL,
  `mairu` decimal(10,2) DEFAULT '0.00',
  `maichu` decimal(10,2) DEFAULT '0.00',
  `cjl` decimal(10,2) DEFAULT '0.00',
  `cje` decimal(10,2) DEFAULT '0.00',
  `chia` varchar(255) DEFAULT '0.00',
  `chib` varchar(255) DEFAULT '0.00',
  `chic` varchar(255) DEFAULT '0.00',
  `chid` varchar(255) DEFAULT NULL,
  `chie` varchar(255) DEFAULT NULL,
  `chiaa` varchar(255) DEFAULT NULL,
  `chiab` varchar(255) DEFAULT NULL,
  `chiac` varchar(255) DEFAULT NULL,
  `chiad` varchar(255) DEFAULT NULL,
  `chiae` varchar(255) DEFAULT NULL,
  `chiba` varchar(255) DEFAULT NULL,
  `chibb` varchar(255) DEFAULT NULL,
  `chibc` varchar(255) DEFAULT NULL,
  `chibd` varchar(255) DEFAULT NULL,
  `chibe` varchar(255) DEFAULT NULL,
  `chica` varchar(255) DEFAULT NULL,
  `chicb` varchar(255) DEFAULT NULL,
  `chicc` varchar(255) DEFAULT NULL,
  `chicd` varchar(255) DEFAULT NULL,
  `chice` varchar(255) DEFAULT NULL,
  `zta` varchar(255) DEFAULT NULL,
  `ztb` varchar(255) DEFAULT NULL,
  `ztc` varchar(255) DEFAULT NULL,
  `ztd` varchar(255) DEFAULT NULL,
  `zte` varchar(255) DEFAULT NULL,
  `ztaa` varchar(255) DEFAULT NULL,
  `ztab` varchar(255) DEFAULT NULL,
  `ztac` varchar(255) DEFAULT NULL,
  `ztad` varchar(255) DEFAULT NULL,
  `ztae` varchar(255) DEFAULT NULL,
  `ztba` varchar(255) DEFAULT NULL,
  `ztbb` varchar(255) DEFAULT NULL,
  `ztbc` varchar(255) DEFAULT NULL,
  `ztbd` varchar(255) DEFAULT NULL,
  `ztbe` varchar(255) DEFAULT NULL,
  `ztda` varchar(255) DEFAULT '0',
  `ztdb` varchar(255) DEFAULT '0',
  `ztdc` varchar(255) DEFAULT '0',
  `ztdd` varchar(255) DEFAULT '0',
  `ztde` varchar(255) DEFAULT '0',
  `zzz` varchar(255) DEFAULT NULL,
  `hzje` decimal(15,2) NOT NULL,
  `hz` varchar(255) DEFAULT '0',
  `jy_money` varchar(255) DEFAULT '0',
  `zsh` varchar(255) DEFAULT '0.00',
  `mj` varchar(255) DEFAULT '0.00',
  `tsl` varchar(255) DEFAULT '0.00',
  `zizeng` varchar(255) DEFAULT NULL COMMENT '币价升职',
  `flv` varchar(255) DEFAULT NULL,
  `flx` varchar(255) DEFAULT NULL,
  `fon` varchar(255) DEFAULT NULL,
  `is_qd` varchar(255) DEFAULT '0',
  `tm` varchar(255) DEFAULT '10000' COMMENT '单价超出限制金额',
  `lm` varchar(255) DEFAULT '10' COMMENT '单价低于限制金额',
  `qy` varchar(255) DEFAULT '100' COMMENT '转出/转入 提交数量必须是大于100的整倍数',
  `zq` varchar(255) DEFAULT '10' COMMENT '今日转账次数限制',
  `jt` varchar(255) DEFAULT '100' COMMENT '今日转账金额限制',
  `icard` int(11) DEFAULT '0' COMMENT '身份认证开关0关1开',
  `opwebt` varchar(255) DEFAULT NULL COMMENT '网站开启时间',
  `clwebt` varchar(255) DEFAULT NULL COMMENT '网站关闭时间',
  `outbl` int(11) DEFAULT '100' COMMENT '卖出比例',
  `buybl` int(11) DEFAULT '0' COMMENT '购买奖励比例',
  `byj` int(11) DEFAULT '0' COMMENT '买币的保证金',
  `tdztra` int(6) DEFAULT NULL COMMENT '领导奖直推人数',
  `tdztrb` int(6) DEFAULT NULL COMMENT '领导奖直推人数',
  `tdztrc` int(6) DEFAULT NULL COMMENT '领导奖直推人数',
  `tdrsa` int(6) DEFAULT NULL COMMENT '领导奖团队人数',
  `tdrsb` int(6) DEFAULT NULL COMMENT '领导奖团队人数',
  `tdrsc` int(6) DEFAULT NULL COMMENT '领导奖团队人数',
  `tdcba` int(10) DEFAULT NULL COMMENT '领导奖 团队持币',
  `tdcbb` int(10) DEFAULT NULL COMMENT '领导奖 团队持币',
  `tdcbc` int(10) DEFAULT NULL COMMENT '领导奖 团队持币',
  `tdjla` decimal(5,2) DEFAULT NULL COMMENT '领导奖奖励比例',
  `tdjlb` decimal(5,2) DEFAULT NULL COMMENT '领导奖奖励比例',
  `tdjlc` decimal(5,2) DEFAULT NULL COMMENT '领导奖奖励比例',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='奖金规则表';

-- -----------------------------
-- Records of `zx_bonus_rule`
-- -----------------------------
INSERT INTO `zx_bonus_rule` VALUES ('1', '奖金规则', '1:300,2:3000', '10', '1:1:1,2:0.9:1,3:0.8:1,4:0.7:1,5:0.6:1,6:0.5:1,7:0.4:1,8:0.3:1,9:0.2:1,10:0.1:1', '1:0.01,2:0.015,3:0.02,4:0.025,5:0.03,6:0.035,7:0.04,8:0.045,9:0.05,10:0.055', '0.1', '1:1000,2:3000,3:5000', '0.00', '0.00', '1', '100', '100', '10000', '200.00', '200', '10', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30', '1:100000:208.33333:100,2:10000:19.44444445:10,3:1000:1.80555556:1,4:100:0.16666667:0.1,5:10:0.01527778:0.01', '1:0.05:3:0.03,2:0.01:30:10,3:0.005:50:15', '50', '1:5:30:0.2,2:15:300:0.15,3:25:3000:0.1,4:50:30000:0.05', '12', '12', '5', '5,50,10,0,0,0,0.2,99', '15,150,30,3,0,0,0.15,99', '45,450,200,0,3,0,0.1,99', '50,30000,0,0,3,0.05,99', '6', '0.24', 'e1269e4cd0224ef0a21ccbc27fde2da4', '1', '3', '2', '39.8', '0', '0.20', '0', '1320', '0,0.8,0.2,1,5,10,20', '0,0.8,0.2,1,1,4,1', '124', '1', '5', '4', '3', '2', '1312', '0', '24', '6.6172', '15.00', '10', '1.00', '10', '0.10', '0', '50', '0.22', '0.25', '5000.00', '1250.00', '6000', '30000', '150000', '300000', '500000', '0.2', '0.25', '0.3', '0.4', '0.5', '1', '2', '3', '4', '6', '6', '8', '10', '12', '0.3', '1', '3', '5', '15', '20', '1', '2', '3', '5000000', '8000000', '15', '20', '30', '0.2', '0.25', '0.00', '0.00', '0.00', '0.00', '0.00', '35', '10.00', '10', '100', '6000000000', '8930000', '5000000', '0.02', '10', '10', '10', '100', '0.20', '0.25', '100', '10', '1000', '1', '7', '24', '100', '10', '10', '3', '5', '10', '10', '50', '100', '3000000', '15000000', '30000000', '0.10', '0.50', '1.00');

-- -----------------------------
-- Table structure for `zx_bonus_total`
-- -----------------------------
DROP TABLE IF EXISTS `zx_bonus_total`;
CREATE TABLE `zx_bonus_total` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `touserid` int(10) DEFAULT NULL COMMENT '会员id',
  `tousernumber` varchar(16) DEFAULT NULL,
  `bonus1` decimal(10,2) DEFAULT '0.00' COMMENT '直推奖',
  `bonus2` decimal(10,2) DEFAULT '0.00' COMMENT '碰对奖',
  `bonus3` decimal(10,2) DEFAULT '0.00' COMMENT '见点奖',
  `bonus4` decimal(10,2) DEFAULT '0.00' COMMENT '日分红',
  `bonus5` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为5的奖项',
  `bonus6` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为6的奖项',
  `bonus7` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为7的奖项',
  `bonus8` decimal(10,2) DEFAULT '0.00' COMMENT '奖金类型为7的奖项',
  `total` decimal(16,2) DEFAULT '0.00' COMMENT '奖金累计',
  `count_date` int(8) DEFAULT NULL,
  `cp_money` decimal(10,2) DEFAULT '0.00' COMMENT '爱心基金',
  `tax_money` decimal(10,2) DEFAULT '0.00' COMMENT '爱心基金',
  PRIMARY KEY (`id`),
  UNIQUE KEY `touserid` (`touserid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='奖金总计表';

-- -----------------------------
-- Records of `zx_bonus_total`
-- -----------------------------
INSERT INTO `zx_bonus_total` VALUES ('1', '14', '18589020061', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '21682.40', '0.00', '5448.29', '1535796990', '0.00', '0.00');
INSERT INTO `zx_bonus_total` VALUES ('2', '15', '18589020062', '0.00', '0.00', '0.00', '0.00', '17.64', '0.00', '6790.80', '0.00', '52133.87', '1535796990', '0.00', '0.00');

-- -----------------------------
-- Table structure for `zx_finance`
-- -----------------------------
DROP TABLE IF EXISTS `zx_finance`;
CREATE TABLE `zx_finance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '财务id',
  `income` double(20,2) DEFAULT '0.00' COMMENT '公司报单收入',
  `expend` double(20,2) DEFAULT '0.00' COMMENT '奖金支出',
  `createtime` int(11) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='公司财务';


-- -----------------------------
-- Table structure for `zx_liuyan`
-- -----------------------------
DROP TABLE IF EXISTS `zx_liuyan`;
CREATE TABLE `zx_liuyan` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fromuserid` int(10) DEFAULT NULL COMMENT '留言用户',
  `touser` int(10) DEFAULT NULL COMMENT '被留言用户',
  `title` varchar(255) DEFAULT NULL COMMENT '留言标题',
  `content` text COMMENT '留言内容',
  `reply` text COMMENT '回复内容',
  `create_time` int(10) DEFAULT NULL COMMENT '请求时间',
  `reply_time` int(10) DEFAULT NULL COMMENT '回复时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '留言状态：未回复（0），已回复（1）删除（-1）',
  `fromstatus` tinyint(4) DEFAULT '1' COMMENT '发件箱删除：删除0，未删除1',
  `tostatus` tinyint(4) DEFAULT '1' COMMENT '收件箱删除：删除0，未删除1',
  `yidu` tinyint(4) DEFAULT '0' COMMENT '0未读 1读了',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员留言';

-- -----------------------------
-- Records of `zx_liuyan`
-- -----------------------------
INSERT INTO `zx_liuyan` VALUES ('1', '0', '1', '充值成功', '公司已经给你充值10000总钱包', '', '1528611632', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('2', '0', '1', '充值成功', '公司已经给你充值10000在线钱包', '', '1528611643', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('3', '0', '1', '充值成功', '公司已经给你充值10000动态钱包', '', '1528611647', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('4', '0', '1', '充值成功', '公司已经给你充值1000总钱包', '', '1528777496', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('5', '0', '1', '充值成功', '公司已经给你充值1010总钱包', '', '1528785681', '', '0', '1', '1', '1');
INSERT INTO `zx_liuyan` VALUES ('6', '0', '1', '测试', '测试', '测试', '1529033724', '1529033876', '1', '1', '1', '1');
INSERT INTO `zx_liuyan` VALUES ('7', '0', '9', '充值成功', '公司已经给你充值10000总钱包', '', '1529055710', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('8', '0', '10', '充值成功', '公司已经给你充值10000总钱包', '', '1529055917', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('9', '0', '11', '充值成功', '公司已经给你充值10000总钱包', '', '1529571720', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('10', '0', '12', '充值成功', '公司已经给你充值10000总钱包', '', '1529572125', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('11', '0', '13', '充值成功', '公司已经给你充值10000总钱包', '', '1529572143', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('12', '0', '13', '充值成功', '公司已经给你充值20000总钱包', '', '1529651004', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('13', '0', '11', '充值成功', '公司已经给你充值20000总钱包', '', '1529651025', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('14', '0', '10', '充值成功', '公司已经给你充值20000总钱包', '', '1529651040', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('15', '0', '9', '充值成功', '公司已经给你充值20000总钱包', '', '1529651055', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('16', '0', '6', '充值成功', '公司已经给你充值20000总钱包', '', '1529651071', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('17', '0', '14', '充值成功', '公司已经给你充值1000总钱包', '', '1535626956', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('18', '0', '14', '充值成功', '公司已经给你充值1000在线钱包', '', '1535626998', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('19', '0', '14', '充值成功', '公司已经给你充值300000总钱包', '', '1535627327', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('20', '0', '14', '充值成功', '公司已经给你充值300000在线钱包', '', '1535627333', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('21', '0', '14', '充值成功', '公司已经给你充值300000在线钱包', '', '1535630873', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('22', '0', '14', '充值成功', '公司已经给你充值1在线钱包', '', '1535630929', '', '0', '1', '1', '0');
INSERT INTO `zx_liuyan` VALUES ('23', '0', '15', '充值成功', '公司已经给你充值1000总钱包', '', '1535736680', '', '0', '1', '1', '0');

-- -----------------------------
-- Table structure for `zx_member`
-- -----------------------------
DROP TABLE IF EXISTS `zx_member`;
CREATE TABLE `zx_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `usernumber` varchar(16) NOT NULL DEFAULT '' COMMENT '用户编号',
  `realname` varchar(255) DEFAULT NULL COMMENT '会员真实姓名',
  `userrank` int(255) DEFAULT '0' COMMENT '用户等级',
  `oldrank` tinyint(6) DEFAULT '0' COMMENT '会员注册时的级别',
  `reg_type` tinyint(2) DEFAULT '1' COMMENT '账户类型：商家（1），会员（0）',
  `tuijianid` int(10) NOT NULL DEFAULT '0' COMMENT '推荐人ID',
  `tuijiannumber` char(16) NOT NULL DEFAULT '0' COMMENT '推荐人帐号',
  `tuijianids` longtext,
  `parentid` int(10) NOT NULL DEFAULT '0' COMMENT '接点人帐号',
  `parentnumber` char(16) NOT NULL DEFAULT '0' COMMENT '接点人帐号',
  `parentids` longtext COMMENT '父辈id',
  `parentareas` longtext COMMENT '父id所在去',
  `reg_uid` mediumint(8) DEFAULT '0' COMMENT '注册人id',
  `active_uid` mediumint(8) DEFAULT '0' COMMENT '激活人id',
  `billcenterid` mediumint(8) DEFAULT '1' COMMENT '报单中心',
  `isbill` tinyint(3) DEFAULT '0' COMMENT '是否是报单中心:0不是，1一级报单中心，2二级报单中心',
  `allbill` double(12,4) DEFAULT '0.0000' COMMENT '报单币',
  `hasbill` double(12,4) DEFAULT '0.0000' COMMENT '报单币余额',
  `hasmoney` decimal(20,4) DEFAULT '0.0000' COMMENT '奖金账户',
  `allmoney` decimal(20,4) DEFAULT '0.0000' COMMENT '进账现金',
  `alljifen` double(10,4) DEFAULT '0.0000' COMMENT '总积分',
  `hasjifen` double(10,4) DEFAULT '0.0000' COMMENT '积分',
  `hascp` double(10,4) DEFAULT '0.0000' COMMENT '动态钱包-积分账户',
  `allcp` double(10,4) DEFAULT '0.0000' COMMENT '进账复消',
  `bill_money` double(10,4) DEFAULT '0.0000' COMMENT '激活时报单金额',
  `allbonus` double(12,4) DEFAULT '0.0000' COMMENT '总奖金',
  `status` int(8) DEFAULT '0' COMMENT '用户状态：-2 删除 ，-1 死了，0 未激活 1 已经激活 ',
  `bankname` varchar(1000) DEFAULT '' COMMENT '银行名称',
  `bankholder` varchar(50) DEFAULT '' COMMENT '开户人姓名',
  `banknumber` varchar(20) DEFAULT NULL COMMENT '银行卡号',
  `IDcard` char(18) DEFAULT '' COMMENT '用户身份证号',
  `wechat` varchar(64) DEFAULT NULL COMMENT '微信号',
  `alipay` varchar(64) DEFAULT NULL COMMENT '支付宝',
  `bite` varchar(255) DEFAULT NULL COMMENT '比特币钱包',
  `area` text COMMENT '会员所在区域',
  `address` varchar(255) DEFAULT '' COMMENT '地址',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `sex` tinyint(3) unsigned DEFAULT '0' COMMENT '性别',
  `email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `active_time` int(10) DEFAULT NULL COMMENT '激活时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员更新时间',
  `wechat_open_id` char(100) DEFAULT NULL COMMENT '微信唯一标识',
  `reg_ip` bigint(20) DEFAULT NULL,
  `psd1` varchar(32) DEFAULT NULL COMMENT '一级密码',
  `psd2` varchar(32) DEFAULT NULL COMMENT '二级密码',
  `pdeep` int(8) DEFAULT '0' COMMENT '该会员相对管理员的层数',
  `tdeep` int(8) DEFAULT '0' COMMENT '该会员相对管理员的代数',
  `recom_num` int(8) DEFAULT '0' COMMENT '推荐人数',
  `zone` int(4) DEFAULT '1' COMMENT '左区（1），右区（2）',
  `znum` mediumint(10) DEFAULT '0' COMMENT '接点人数',
  `left_zone` tinyint(1) DEFAULT '0' COMMENT '左区是否被占',
  `right_zone` tinyint(1) DEFAULT '0' COMMENT '右区是否被占',
  `proxy_state` tinyint(2) DEFAULT '0' COMMENT '分红状态',
  `last_rec_time` int(10) DEFAULT '0' COMMENT '最后一个推荐人的激活时间',
  `left_bill_all` double(16,2) DEFAULT '0.00' COMMENT '右边总单量',
  `left_bill` double(16,2) DEFAULT '0.00' COMMENT '右边总单量',
  `right_bill_all` double(16,2) DEFAULT '0.00' COMMENT '右边总单量',
  `right_bill` double(16,2) DEFAULT '0.00' COMMENT '右边总单量',
  `update_regtype` longtext COMMENT '下线满足条件职务数',
  `active_type` tinyint(2) DEFAULT '1' COMMENT '空单(0)or实单(1)',
  `level_bill` tinyint(3) DEFAULT NULL COMMENT '不同级别用户对应单数',
  `relation_id` int(11) DEFAULT '0' COMMENT '关系id',
  `touzi` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '投资额',
  `static_money` decimal(10,2) DEFAULT '0.00' COMMENT '静态收益的积分',
  `chuju` tinyint(4) NOT NULL DEFAULT '0',
  `suanli` double(16,2) DEFAULT '0.00' COMMENT '个人总算力',
  `zt_suanli` double(16,2) DEFAULT '0.00' COMMENT '直推算力',
  `is_gonghui` tinyint(4) DEFAULT '0' COMMENT '0代表未创建公会 1代表创建公会了',
  `gonghuiid` int(11) DEFAULT '0' COMMENT '公会id',
  `IDcard_z` varchar(255) DEFAULT NULL COMMENT '身份证正面照片地址',
  `IDcard_f` varchar(255) DEFAULT NULL COMMENT '身份证发面照片',
  `zheng_z` varchar(255) DEFAULT NULL,
  `zheng_f` varchar(255) DEFAULT NULL,
  `shenpi` tinyint(4) DEFAULT '3' COMMENT '0未上传1已上传3已审批4拒绝',
  `sp_time` varchar(255) DEFAULT NULL COMMENT '审批通过时间戳',
  `skype` varchar(255) DEFAULT NULL,
  `ytf` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `team` int(10) DEFAULT '0' COMMENT '团队人数',
  `info` varchar(255) DEFAULT NULL COMMENT '冻结原因',
  `qianming` varchar(255) DEFAULT NULL COMMENT '个性签名',
  `is_vip` tinyint(4) DEFAULT '0' COMMENT '0不是1是',
  `vip_start` char(10) DEFAULT '0' COMMENT 'vip开始时间',
  `vip_end` char(10) DEFAULT '0' COMMENT 'vip结束时间',
  `qiandao` varchar(255) DEFAULT NULL,
  `province` int(11) DEFAULT '0' COMMENT '省',
  `city` int(11) DEFAULT '0' COMMENT '市',
  `is_qd` varchar(255) DEFAULT '0',
  `qianbao` char(20) NOT NULL,
  `hassf` double(10,4) DEFAULT '0.0000' COMMENT '孵化仓',
  `hasfh` double(10,4) DEFAULT '0.0000',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `usernumber` (`usernumber`) USING BTREE,
  UNIQUE KEY `qianbao` (`qiandao`),
  KEY `status` (`status`) USING BTREE,
  KEY `tuijianid` (`tuijianid`) USING BTREE,
  KEY `deep` (`tdeep`) USING BTREE,
  KEY `recom_num` (`recom_num`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员信息表';

-- -----------------------------
-- Records of `zx_member`
-- -----------------------------
INSERT INTO `zx_member` VALUES ('2', '13289223171', '柴雅芙', '2', '0', '0', '1', '13289223170', ',1,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '', '柴雅芙', '', '', '', '', '', '', '', '13289223171', '0', '', '1528606338', '1528606338', '0', '', '0', '123456', '123456', '0', '1', '6', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.70', '0.60', '0', '0', '', '', '', '', '3', '', '', '', '', '', '6', '', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('3', 'qweqweqewqe', '匡烨霖1', '2', '0', '0', '1', '13289223170', ',1,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '123', '', '123', '123', '123', '123', '', ',,', '', 'qweqweqewqe', '0', '', '1528606353', '1528606353', '0', '', '0', '123456', '123456', '0', '1', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '123', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('4', '123', '竺妙菱', '2', '0', '0', '1', '13289223170', ',1,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '', '竺妙菱', '', '', '', '', '', '', '', '123', '0', '', '1528613568', '1528613568', '0', '', '0', '123456', '123456', '0', '1', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('6', '18049553861', '123', '2', '0', '0', '1', '13289223170', ',1,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '123', '咸建辉', '123', '123', '123', '213213', '', '', '', '18049553861', '0', '', '1528618962', '1528618962', '0', '', '0', '123456', '123456', '0', '1', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('11', '18391032562', '李晶', '2', '0', '0', '2', '13289223171', ',1,2,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '工商银行', '', '6212604211785642', '610425199805061183', '18391032562', '18391032562', '', '', '', '18391032562', '0', '', '1529571540', '1529571540', '0', '', '3395560053', '123456', '123456', '0', '2', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('9', '17602906158', '张明娟', '2', '0', '0', '2', '13289223171', ',1,2,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '太白路支行', '张明娟', '6000059874566952', '610105125987156966', '1234566', '1234566@qq.com', '', '', '', '17602906158', '0', '', '1529053870', '1529053870', '0', '', '3395564187', '123456', '123456', '0', '2', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '0', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('10', '15929285804', '周青青', '2', '0', '0', '2', '13289223171', ',1,2,', '0', '0', '', '', '8', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '咸阳陕西科技大学人民路支行', '', '1122334455667788990', '112233445566778899', '123456789', '123456789', '', '', '', '15929285804', '0', '', '1529055753', '1529055753', '0', '', '3395564187', '112255', '123456', '0', '2', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '1', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('12', '17629155243', '周美', '2', '0', '0', '2', '13289223171', ',1,2,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '招商银行', '', '1223654898215547', '625347925113141541', 'sdiahdf', '13354287256', '', '', '', '17629155243', '0', '', '1529572044', '1529572044', '0', '', '3395560053', '123456', '123456', '0', '2', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '1', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('1', '13289223170', '王卓璞', '2', '0', '0', '0', '0', '', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '1', '123465789', '谈雨婷', '123456789123456', '1234657892143', '123123465', '123123456', '', '', '', '13289223170', '0', '', '1528602497', '1528602497', '0', '', '0', '123456', '123456', '0', '0', '6', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '1.40', '0.60', '0', '0', '', '', '', '', '3', '', '', '', '', '', '13', '', '', '0', '0', '0', '', '0', '0', '1', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('14', '18589020061', 'ljy', '2', '0', '0', '1', '13289223170', ',1,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '10000.0000', '301.6830', '0.0000', '100.0000', '100.0000', '201.6830', '0.0000', '0.0000', '0.0000', '1', '梅陇支行', '仰鹤轩', '123456789', '123456789987654321', 'weixin666', 'zhifubao888', '', '', '', '18589020061', '0', '', '1535626866', '1535626866', '0', '', '2130706433', '123456', '123456', '0', '1', '1', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.20', '0.10', '0', '0', '', '', '', '', '3', '', '', '', '', '', '1', '', '', '0', '0', '0', '', '0', '0', '1', '', '0.0000', '0.0000');
INSERT INTO `zx_member` VALUES ('15', '18589020062', 'langlang', '2', '0', '0', '14', '18589020061', ',1,14,', '0', '0', '', '', '0', '0', '1', '0', '0.0000', '5500.0000', '466.0000', '0.0000', '66.0000', '66.0000', '400.0000', '0.0000', '0.0000', '0.0000', '1', '', '', '', '', '', '', '', '', '', '18589020062', '0', '', '1535629362', '1535629361', '0', '', '2130706433', '123456', '123456', '0', '2', '0', '1', '0', '0', '0', '1', '0', '0.00', '0.00', '0.00', '0.00', '', '1', '', '0', '0.00', '0.00', '0', '0.10', '0.00', '0', '0', '', '', '', '', '3', '', '', '', '', '', '0', '', '', '0', '0', '0', '', '0', '0', '1', '', '0.0000', '1.7570');

-- -----------------------------
-- Table structure for `zx_money_change`
-- -----------------------------
DROP TABLE IF EXISTS `zx_money_change`;
CREATE TABLE `zx_money_change` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `moneytype` tinyint(4) DEFAULT '2' COMMENT '币种，默认现金',
  `status` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '奖金状态 0 失败 1 成功',
  `targetuserid` int(10) NOT NULL DEFAULT '0' COMMENT '目标账户',
  `targetusernumber` char(16) NOT NULL DEFAULT '' COMMENT '目标账户编号',
  `userid` int(10) NOT NULL DEFAULT '0',
  `usernumber` char(16) NOT NULL DEFAULT '' COMMENT '进账用户编号',
  `changetype` int(6) unsigned NOT NULL DEFAULT '0' COMMENT '变更类型 ：',
  `recordtype` int(2) DEFAULT NULL COMMENT '记录类型：减少（0），增加（1）',
  `money` decimal(20,4) DEFAULT '0.0000' COMMENT '变更金额',
  `hasmoney` decimal(20,4) DEFAULT '0.0000' COMMENT '账户余额',
  `tax_money` double(10,4) DEFAULT '0.0000' COMMENT '税金',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `op` varchar(32) DEFAULT NULL COMMENT '相同操作标识',
  `cp_money` double(10,4) DEFAULT '0.0000' COMMENT '复消累计',
  PRIMARY KEY (`id`),
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1397 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='财务流水';

-- -----------------------------
-- Records of `zx_money_change`
-- -----------------------------
INSERT INTO `zx_money_change` VALUES ('1396', '3', '1', '14', '18589020061', '0', '0', '34', '1', '0.0110', '10000.0000', '0.0000', '1535797142', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1395', '3', '1', '14', '18589020061', '0', '0', '34', '1', '0.0110', '10000.0000', '0.0000', '1535797072', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1394', '3', '1', '14', '18589020061', '0', '0', '34', '1', '0.0110', '10000.0000', '0.0000', '1535797051', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1393', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '400.0000', '0.0000', '1535796990', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1392', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '201.6500', '0.0000', '1535796990', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1391', '3', '1', '14', '18589020061', '0', '0', '13', '1', '100.0000', '10000.0000', '0.0000', '1535790997', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1390', '3', '1', '14', '18589020061', '0', '0', '33', '1', '1.6500', '10000.0000', '0.0000', '1535790997', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1389', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '200.0000', '0.0000', '1535790997', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1388', '3', '1', '14', '18589020061', '0', '0', '13', '1', '100.0000', '10000.0000', '0.0000', '1535790696', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1387', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '100.0000', '0.0000', '1535790696', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1386', '3', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535790676', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1385', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '400.0000', '0.0000', '1535790676', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1384', '3', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535787079', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1383', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '300.0000', '0.0000', '1535787079', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1382', '4', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535787039', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1381', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '200.0000', '0.0000', '1535787039', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1380', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '100.0000', '0.0000', '1535786058', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1379', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '0.0000', '0.0000', '1535786058', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1378', '3', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535783724', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1377', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '100.0000', '0.0000', '1535783724', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1376', '1', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535783419', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1375', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '100.0000', '0.0000', '1535783419', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1374', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '0.0000', '0.0000', '1535783419', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1373', '1', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535783162', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1372', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '5800.0000', '0.0000', '1535783162', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1371', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '42.0000', '0.0000', '1535783162', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1370', '1', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535783067', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1369', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '5700.0000', '0.0000', '1535783067', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1368', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '42.0000', '0.0000', '1535783067', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1367', '1', '1', '15', '18589020062', '0', '0', '13', '1', '100.0000', '5500.0000', '0.0000', '1535782837', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1366', '4', '1', '15', '18589020062', '0', '0', '7', '1', '11.0000', '5600.0000', '0.0000', '1535782837', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1365', '4', '1', '14', '18589020061', '0', '0', '7', '1', '25.0000', '42.0000', '0.0000', '1535782837', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1364', '2', '1', '15', '18589020062', '15', '18589020062', '24', '1', '500.0000', '', '0.0000', '1535736710', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1363', '2', '1', '15', '18589020062', '15', '18589020062', '24', '0', '500.0000', '', '0.0000', '1535736710', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1362', '3', '1', '14', '18589020061', '15', '18589020062', '20', '1', '30.0000', '12.0000', '0.0000', '1535736710', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1361', '2', '1', '15', '18589020062', '0', '0', '21', '1', '1000.0000', '1000.0000', '0.0000', '1535736680', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1359', '3', '1', '14', '18589020061', '15', '18589020062', '20', '1', '6.0000', '0.0000', '0.0000', '1535735718', '', '0.0000');
INSERT INTO `zx_money_change` VALUES ('1360', '3', '1', '14', '18589020061', '15', '18589020062', '20', '1', '6.0000', '6.0000', '0.0000', '1535736124', '', '0.0000');

-- -----------------------------
-- Table structure for `zx_recharge`
-- -----------------------------
DROP TABLE IF EXISTS `zx_recharge`;
CREATE TABLE `zx_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '提现ID',
  `type` int(4) DEFAULT '1' COMMENT '充值类型:1-报单币，5-复消币',
  `order_id` varchar(255) DEFAULT NULL COMMENT '支付编号',
  `userid` int(10) DEFAULT '0' COMMENT '对应用户id',
  `usernumber` varchar(64) DEFAULT '' COMMENT '对应用户编号',
  `bankholder` varchar(16) NOT NULL COMMENT '开户人',
  `bankname` varchar(16) DEFAULT NULL COMMENT '银行名称',
  `banknumber` varchar(20) DEFAULT NULL COMMENT '银行卡号',
  `mobile` varchar(12) DEFAULT NULL COMMENT '汇款人手机号',
  `money` double(10,2) DEFAULT '0.00' COMMENT '提现金额',
  `out_banknumber` varchar(20) DEFAULT NULL COMMENT '汇出账户',
  `out_bankholder` varchar(16) DEFAULT NULL COMMENT '汇出账户开户人',
  `out_bankname` varchar(16) DEFAULT NULL COMMENT '汇款开户行',
  `outtime` varchar(20) DEFAULT NULL COMMENT '汇款时间',
  `message` varchar(255) DEFAULT '' COMMENT '奖金提现状态提现留言',
  `cause` varchar(255) DEFAULT '',
  `handtime` int(10) DEFAULT NULL COMMENT '处理时间',
  `createtime` int(10) unsigned DEFAULT '0' COMMENT '申请日期',
  `callback` text COMMENT '支付成功的回调函数',
  `url` text COMMENT '支付完成后的跳转地址',
  `status` int(3) DEFAULT '0' COMMENT '奖金提现状态 1 充值，0未充值',
  PRIMARY KEY (`id`),
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='充值申请';


-- -----------------------------
-- Table structure for `zx_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `zx_ucenter_member`;
CREATE TABLE `zx_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `email` char(32) DEFAULT NULL COMMENT '用户邮箱',
  `password` char(32) NOT NULL COMMENT '密码',
  `password2` char(32) DEFAULT NULL COMMENT '二级密码',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `login_count` bigint(20) DEFAULT '0' COMMENT '登录次数',
  `status` tinyint(4) DEFAULT '1' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员登陆表';

-- -----------------------------
-- Records of `zx_ucenter_member`
-- -----------------------------
INSERT INTO `zx_ucenter_member` VALUES ('2', '13289223171', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '0', '0', '0', '1');
INSERT INTO `zx_ucenter_member` VALUES ('4', '123', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '0', '0', '0', '1');
INSERT INTO `zx_ucenter_member` VALUES ('6', '18049553861', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1529046180', '0', '6', '1');
INSERT INTO `zx_ucenter_member` VALUES ('11', '18391032562', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1529650263', '1965323488', '3', '1');
INSERT INTO `zx_ucenter_member` VALUES ('9', '17602906158', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1529652843', '1965323488', '4', '1');
INSERT INTO `zx_ucenter_member` VALUES ('10', '15929285804', '', 'e71f2de6996265099e9ac32627b32506', '6f5760a139b91250651837f529d90d18', '1529649797', '1965323488', '7', '1');
INSERT INTO `zx_ucenter_member` VALUES ('12', '17629155243', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1529649111', '1965323488', '2', '1');
INSERT INTO `zx_ucenter_member` VALUES ('14', '18589020061', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1535948509', '2130706433', '5', '1');
INSERT INTO `zx_ucenter_member` VALUES ('15', '18589020062', '', '6f5760a139b91250651837f529d90d18', '6f5760a139b91250651837f529d90d18', '1535779841', '2130706433', '4', '1');

-- -----------------------------
-- Table structure for `zx_withdrawal`
-- -----------------------------
DROP TABLE IF EXISTS `zx_withdrawal`;
CREATE TABLE `zx_withdrawal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '提现ID',
  `moneytype` int(1) unsigned DEFAULT '0' COMMENT '提现类型 1 奖金，2 电子币',
  `userid` int(10) DEFAULT '0' COMMENT '对应用户id',
  `usernumber` char(16) DEFAULT '' COMMENT '对应用户编号',
  `bankholder` varchar(16) NOT NULL COMMENT '开户人',
  `bankname` varchar(16) DEFAULT NULL COMMENT '银行名称',
  `banknumber` varchar(20) DEFAULT NULL COMMENT '银行卡号',
  `mobile` varchar(12) DEFAULT NULL COMMENT '收件号',
  `money` double(10,2) DEFAULT '0.00' COMMENT '提现金额',
  `fee` double(10,2) DEFAULT '0.00' COMMENT '提现手续费',
  `createtime` int(10) unsigned DEFAULT '0' COMMENT '提现日期',
  `status` int(4) DEFAULT '0' COMMENT '奖金提现状态 0 提现成功 ，1 申请提现 ， 2 提现失败',
  `message` varchar(255) DEFAULT '' COMMENT '奖金提现状态提现留言',
  `replyms` varchar(255) DEFAULT NULL,
  `handtime` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='提现申请表';

